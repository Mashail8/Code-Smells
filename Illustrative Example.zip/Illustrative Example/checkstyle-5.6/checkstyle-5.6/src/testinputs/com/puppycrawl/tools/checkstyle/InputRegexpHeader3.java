package blah;

import java.awt.*;

public class InputRegexpHeader3
{
}

package blah;


/**
 */
public class InputRegexpSmallHeader {}

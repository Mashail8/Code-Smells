import java.applet.Applet;
import java.applet.AudioClip;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.KeyAdapter;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Random;

import javax.swing.Timer;

public class GamePaneData {
	public Node tetris;
	public Timer timer;
	public Timer timer1;
	public Timer timer2;
	public Timer anim_timer;
	public Image[] img;
	public Image fpipe;
	public Image bpipe;
	public String[] files;
	public AudioClip[] clips;
	public Toolkit tk;
	public Random rand;
	public int rot;
	public int len;
	public boolean reached;
	public int count;
	public boolean started;
	public boolean gameOver;
	public boolean paused;
	public int a;
	public int b;
	public int level;
	public int score;
	public int pieces;
	public int removed_puyos;
	public int minscore;
	public int anim;
	public float alpha;
	public float alpha1;
	public boolean levelflag;

	public GamePaneData(Image[] img, String[] files, AudioClip[] clips) {
		this.img = img;
		this.files = files;
		this.clips = clips;
	}

	public void loadImages(GamePane gamePane)//loading images into the image array and pipe objects
	{
		String s="";
		if(len>=42)
		s="_";
		for(int i=0;i<img.length;i++)
		img[i]=tk.getImage("images\\puyo_"+s+(i+1)+".png");
		fpipe=tk.getImage("images\\pipe"+s+"1.png");
		bpipe=tk.getImage("images\\pipe"+s+".png");
	}

	public void setDelays(GamePane gamePane)
	{
		int delay=0,delay1=0;
		for(int i=0;i<=level;i++)//to set the delays depending on the level
		{
			delay+=20*(4-i/5);	
			delay1+=4-i/5;
		}
		if(level==20)
		{
			delay+=25;
			delay1+=1;
		}
		timer.setDelay(1075-delay);
		anim_timer.setDelay(52-delay1);
		anim_timer.restart();
	}

	public void setDelays(KeyAdapter keyAdapter) {
		// TODO Auto-generated method stub
		
	}

	public void loadSounds(GamePane gamePane)//loading souds into the AudioClip array
	{
		try{
			for(int i=0;i<clips.length;i++)	//Loading all the sound clips
			clips[i]=Applet.newAudioClip(new URL("file:"+System.getProperty("user.dir")+"\\sounds\\"+files[i]));
			
		}
		catch (MalformedURLException e) {
	        System.err.println(e.getMessage());
	    }
	}
}